<?php
	echo '<footer class="footer navbar-inverse navbar-fixed-bottom">
      <div class="container">
        <p class="text-muted" align="center">Copyright &copy; DuesWala, 2015.</p>
      </div>
    </footer>';
?>