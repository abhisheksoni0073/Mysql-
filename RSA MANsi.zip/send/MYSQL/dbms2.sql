-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2019 at 03:31 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbms2`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `name` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`username`),
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `username`, `password`) VALUES
('Admin', 'admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `admin_email`
--

CREATE TABLE IF NOT EXISTS `admin_email` (
  `email` varchar(20) NOT NULL,
  `key` varchar(100) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_email`
--

INSERT INTO `admin_email` (`email`, `key`) VALUES
('demo', 'Z2vvZV3FA0'),
('demo1', 'nL09spYGKG'),
('demo2', 'HsdaUPmZPB');

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE IF NOT EXISTS `email` (
  `roll` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `key` varchar(100) NOT NULL,
  PRIMARY KEY (`roll`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email`
--

INSERT INTO `email` (`roll`, `email`, `key`) VALUES
(12345, 'test@gmail.com', '5rfBjjPMNf'),
(54321, 'abhisheksoni2495@gma', 'rQZilES4cx');

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE IF NOT EXISTS `manager` (
  `name` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(20) NOT NULL,
  `hostel` varchar(20) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`name`, `username`, `password`, `role`, `hostel`) VALUES
('demo', 'demo', 'demo', 'mess', ''),
('demo1', 'demo1', 'demo1', 'hostel', ''),
('demo2', 'demo2', 'demo2', 'other', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `msg`
--

CREATE TABLE IF NOT EXISTS `msg` (
  `ns` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `msg` varchar(20) NOT NULL,
  `time` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `name` varchar(20) NOT NULL,
  `roll` int(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `hostel` varchar(20) NOT NULL,
  PRIMARY KEY (`roll`),
  KEY `roll` (`roll`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`name`, `roll`, `password`, `hostel`) VALUES
('test', 12345, 'test', ''),
('abhishek', 54321, 'abhishek', '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_email`
--
ALTER TABLE `admin_email`
  ADD CONSTRAINT `admin_email_ibfk_1` FOREIGN KEY (`email`) REFERENCES `manager` (`username`);

--
-- Constraints for table `email`
--
ALTER TABLE `email`
  ADD CONSTRAINT `email_ibfk_1` FOREIGN KEY (`roll`) REFERENCES `student` (`roll`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
