<?php
	include('db_connection.php');
	if(session_id()==""){
		session_start();
	}
	if(!isset($_SESSION['login_as'])){
		header('location:index.php');
	}
	$due = 0;
	$query = mysql_query("select * from mess_due where roll_number='".$_SESSION['roll']."'",$connection);
	
	
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/icon.png">

    <title><?php echo $_SESSION['name'];?></title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/signin.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>
  	<!--Navbar Begins-->
  	<nav class="navbar navbar-default navbar-fixed-top">
	  <div class="container">
	  	<h3 class="navbar-text"><a href="#"><span class="glyphicon glyphicon-home" title="Home" aria-hidden="true"></span></a></h3>
	  	<h3 class="navbar-text"><a href="setting.php"><span class="glyphicon glyphicon-wrench" title="Settings" aria-hidden="true"></span></a></h3>
	    <h3 class="navbar-text"><?php echo "Welcome ".$_SESSION['name'];?></h3>
	    <h3 class="navbar-text navbar-right"><a href="logout.php"><span class="glyphicon glyphicon-log-out" title="Log Out" aria-hidden="true"></span></a></h3>
	  </div>
	</nav>
	<!--Navbar Ends-->
	<br>
	<!--Nav Begins-->
	












	
	
	<div style="margin-top:5%;">
		<h2 align="center" id="pass-message">RSA MESSAGE</h2>
		<br><br>
		<form class="form-horizontal" method="post">
			<div class="form-group">
		    	<label for="inputEmail3" class="col-sm-5 control-label">Message</label>
		    	<div class="col-sm-4">
		     		<input type="password" class="form-control" id="inputEmail3" name="password" placeholder="Enter Your Message" required>
		    	</div>
		  	</div>
		  
		  	
		  	</div>
		  	<div class="form-group">
		  		<div class="col-sm-5"></div>
		  		<div class="col-sm-4">
		    		<button type="submit" class="btn btn-primary">Send Message</button>
		    	</div>
		  	</div>
		</form>
	</div>	
	
	
	<!--Nav Ends-->

	<?php //include('footer.php');?>
  </body>
 </html>